import os
import sqlite3
import requests

def set_up_database(db_name):
    """
    Sets up the SQLite database and creates the Movies table if it doesn't exist.
    """
    conn = sqlite3.connect(db_name)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS Movies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT UNIQUE,
            year INTEGER,
            genre TEXT,
            country TEXT,
            imdb_rating REAL
        )
    """)
    conn.commit()
    return cur, conn

def movie_exists(cur, title):
    """
    Checks if a movie with the given title already exists in the database.
    """
    cur.execute("SELECT 1 FROM Movies WHERE title = ?", (title,))
    return cur.fetchone() is not None

def get_current_movie_count(cur):
    """
    Returns the current number of movies in the database.
    """
    cur.execute("SELECT COUNT(*) FROM Movies")
    return cur.fetchone()[0]

def fetch_movies_2024(cur, conn, max_insert=25, total_limit=100):
    """
    Fetches up to `max_insert` movies from the year 2024 using the OMDB API
    and ensures the total count in the database does not exceed `total_limit`.
    """
    base_url = "http://www.omdbapi.com/"
    api_key = "25781136"  # Replace with your valid API key
    year = 2024
    current_insert_count = 0
    page = 1

    # Check the current movie count
    total_current_count = get_current_movie_count(cur)
    print(f"Movies currently in database: {total_current_count}")

    if total_current_count >= total_limit:
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print(f"The database is already full with {total_current_count} movies. No more movies will be fetched.")
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        return

    print(f"Starting fetch to add up to {max_insert} movies.")

    while current_insert_count < max_insert and total_current_count < total_limit:
        response = requests.get(base_url, params={
            "s": "movie",
            "type": "movie",
            "y": year,
            "page": page,
            "apikey": api_key
        })

        if response.status_code != 200:
            print(f"Error fetching movies: {response.status_code}")
            return

        data = response.json()
        if data.get("Response") != "True":
            print(f"No more movies found on page {page}.")
            return

        for movie in data.get("Search", []):
            if current_insert_count >= max_insert or total_current_count >= total_limit:
                print("Stopping fetch: Max limit reached.")
                break

            # Fetch full movie details
            imdb_id = movie.get("imdbID")
            full_data = requests.get(base_url, params={"i": imdb_id, "apikey": api_key}).json()

            if full_data.get("Response") == "True":
                title = full_data.get("Title")
                movie_year = full_data.get("Year")

                # Strict year check
                if movie_year != str(year):
                    print(f"Skipping movie '{title}' from year {movie_year}")
                    continue

                genre = full_data.get("Genre", "N/A")
                country = full_data.get("Country", "N/A")
                imdb_rating = full_data.get("imdbRating", "0.0")
                if imdb_rating == "N/A":
                    imdb_rating = 0.0

                # Avoid duplicates
                if movie_exists(cur, title):
                    print(f"Skipping duplicate movie: {title}")
                    continue

                # Insert movie into the database
                try:
                    cur.execute("""
                        INSERT INTO Movies (title, year, genre, country, imdb_rating)
                        VALUES (?, ?, ?, ?, ?)
                    """, (title, int(movie_year), genre, country, float(imdb_rating)))
                    conn.commit()
                    current_insert_count += 1
                    total_current_count += 1
                    print(f"Inserted movie: {title}")
                except sqlite3.IntegrityError:
                    print(f"Movie '{title}' already exists in the database.")

        page += 1

    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print(f"Fetch process completed. Movies added this run: {current_insert_count}")
    print(f"Total movies in database: {total_current_count}")
    print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")

def main():
    """
    Main function for setting up the database and fetching movies.
    """
    db_name = "movies123.db"
    cur, conn = set_up_database(db_name)

    # Step 1: Fetch movies and populate the table (limit 25 per run)
    fetch_movies_2024(cur, conn, max_insert=25, total_limit=100)

    # Close the database connection
    conn.close()

if __name__ == "__main__":
    main()
